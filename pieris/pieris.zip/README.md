# PS-ReverseShell
This tool is for educational purpose only and im not responsable for any actions done with it.

Use #help to get help
Use #download "<filename>" "<dir>" to download <dir> from the client pc to the <filename> in the "shared_files" folder on the server pc
Use #upload "<filename>" "<dir>" to upload <filename> from the "shared_files" dir on the server pc to the <dir> on the client pc
Use #load "<filename>" to load and run a <filename> from the "scripts" folder