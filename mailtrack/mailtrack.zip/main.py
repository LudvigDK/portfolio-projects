# --- BUGS ---
# 
# 
# 
# ------------

import flask
import threading
import time
import os
import json

"""import click
class CH: # ConsoleHandler
    class Type:
        ERROR = 0
        WARNING = 1
        SUCCESS = 2
        INFO = 3
        DEBUG = 4

    def print()"""

import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

TRACKERS = {}
DEFAULT_TRACKER_DICT = {
    'is_active':False,
    'total_hits':0,
    'active_mask':None
}
DEBUGGING_ENABLED = False
CURRENT_SESSION = None

app = flask.Flask(__name__)

"""@app.route('/')
def hello():
    print(f"Client IP: {flask.request.headers.get('X-Forwarded-For')}")
    return "Hello, World!"""

@app.route('/<path:path>')
def mask_redirector(path):
    global TRACKERS
    for key in TRACKERS:
        tracker = TRACKERS[key]
        if not tracker['active_mask']:
            continue
        if tracker['active_mask'].removeprefix('/').removesuffix('/') == path:
            #return flask.redirect(f'/track/{key}')
            return track(key)
    return flask.Response(status=404)

@app.route('/track/<tracking_id>')
def track(tracking_id):
    global TRACKERS
    if not tracking_id in TRACKERS.keys():
        return flask.Response(status=404)
    if TRACKERS[tracking_id]['is_active']:
        TRACKERS[tracking_id]['total_hits'] += 1
        print(f'\rGot new hit from "{flask.request.remote_addr}" on "{tracking_id}". Total hits: {TRACKERS[tracking_id]["total_hits"]}\n-> ', end='')
    return flask.send_file('single_pixel.png', mimetype='image/png')

def command_parser(cmd:str):
    global TRACKERS
    def command_not_found(**kwargs):
        print('Command not found, use help to see all commands.')
    def help(**kwargs):
        print('''
Exit:
    exit to exit the program.
              
Track:
    --- new ---
        track new <id> in order to create a new tracking id.
              
    --- get ---
        track get <id> in order to get tracking data from id.
              
    --- activate/deactivate ---
        track activate <id> in order to activate a tracker.
        track activate all in order to activate a tracker.
        track deactivate <id> in order to deactivate a specific tracker.
        track deactivate all in order to deactivate all trackers.
              
    --- list ---
        track list all in order to list all trackers.
        track list active in order to list all active trackers.
              
    --- delete ---
        track delete <id> in order to delete a specific tracker.
        track delete all in order to delete all trackers.
              
    --- reset ---
        track reset <id> in order to reset a specific tracker.
        track reset all in order to reset all trackers.
    
    --- mask ---
        track mask <delete/set> <id> <path> in order to mask the /track/<id> path with the <path> provided.
              

Session:
    --- save ---
        session save <session_id> saves the current session under the specified id, the id is then used again when loading the session.
              
    --- load ---
        session load <session_id> loads the session with the corresponding session_id.
              
    --- list ---
        session list lists all saved sessions.
    
    --- current ---
        session current prints out you current sesssion.


Debug:
    --- on ---
    debug on enables debugging for errors, this means more info will be printet on errors.
    
    --- off ---
    debug off disables debugging for errors.
    
    --- state ---
    debug state prints the current debugging state.
''')
    def track(**kwargs):
        def does_exist(id):
            if id == 'all':
                return True
            if TRACKERS.get(id):
                return True
            return False
        cmd_args = kwargs.get('cmd_args')
        if not cmd_args:
            command_not_found()
            return
        if cmd_args[0] == 'new':
            if does_exist(cmd_args[1]):
                print(f'A tracker with id "{cmd_args[1]}" already exists.')
                return
            TRACKERS[cmd_args[1]] = DEFAULT_TRACKER_DICT.copy()
            print(f'New tracker created with id: "{cmd_args[1]}"')
            print(f'Url is: "/track/{cmd_args[1]}')
        elif cmd_args[0] == 'get':
            if not does_exist(cmd_args[1]):
                print(f'There is no tracker with {cmd_args[1]} as its id.')
                return
            print(f'Tracker "{cmd_args[1]}" has {TRACKERS[cmd_args[1]]["total_hits"]} hits.')
        elif cmd_args[0] == 'activate':
            if not does_exist(cmd_args[1]):
                print(f'There is no tracker with {cmd_args[1]} as its id.')
                return
            if cmd_args[1] == 'all':
                for tracker in TRACKERS.keys():
                    TRACKERS[tracker]['is_active'] = True
                print('All trackers activated')
                return
            TRACKERS[cmd_args[1]]['is_active'] = True
            print(f'Tracker "{cmd_args[1]}" activated.')
        elif cmd_args[0] == 'list':
            if cmd_args[1] == 'all':
                for key in TRACKERS:
                    tracker = TRACKERS[key]
                    print(f'[{"ACTIVE" if tracker["is_active"] else "NOT ACTIVE"}] Tracker "{key}", Total hits: {tracker["total_hits"]}, Active Mask: "{tracker["active_mask"]}"')
                print('')
            elif cmd_args[1] == 'active':
                for key in list(filter(lambda key: TRACKERS[key]['is_active'], TRACKERS.keys())):
                    tracker = TRACKERS[key]
                    print(f'[{"ACTIVE" if tracker["is_active"] else "NOT ACTIVE"}] Tracker "{key}", Total hits: {tracker["total_hits"]}, Active Mask: "{tracker["active_mask"]}"')
                print('')
        elif cmd_args[0] == 'deactivate':
            if not does_exist(cmd_args[1]):
                print(f'There is no tracker with {cmd_args[1]} as its id.')
                return
            if cmd_args[1] == 'all':
                for tracker in TRACKERS.keys():
                    TRACKERS[tracker]['is_active'] = False
                print('All trackers deactivated')
                return
            TRACKERS[cmd_args[1]]['is_active'] = False
            print(f'Tracker "{cmd_args[1]}" deactivated.')
        elif cmd_args[0] == 'delete':
            if cmd_args[1] == 'all':
                TRACKERS.clear()
                return
            TRACKERS.pop(cmd_args[1], None)
            print(f'Tracker "{cmd_args[1]}" was deleted.')
        elif cmd_args[0] == 'reset':
            if not does_exist(cmd_args[1]):
                print(f'There is no tracker with {cmd_args[1]} as its id.')
                return
            if cmd_args[1] == 'all':
                for tracker in TRACKERS.keys():
                    TRACKERS[cmd_args[1]] = DEFAULT_TRACKER_DICT.copy()
                print('All trackers reset.')
                return
            TRACKERS[cmd_args[1]] = DEFAULT_TRACKER_DICT.copy()
            print(f'Tracker "{cmd_args[1]}" has been reset.')
        elif cmd_args[0] == 'mask':
            if not does_exist(cmd_args[2]):
                print(f'There is no tracker with {cmd_args[2]} as its id.')
                return
            if cmd_args[1] == 'set':
                TRACKERS[cmd_args[2]]['active_mask'] = cmd_args[3]
                print(f'New mask applied to {cmd_args[2]}.')
            elif cmd_args[1] == 'delete':
                TRACKERS[cmd_args[2]]['active_mask'] = cmd_args[3]
                print(f'Deleted the mask applied to {cmd_args[2]}.')
    
    def session(**kwargs):
        global DEBUGGING_ENABLED, TRACKERS, CURRENT_SESSION
        cmd_args = kwargs.get('cmd_args')
        if cmd_args[0] == 'load':
            if not input('Are you sure you want to load a new session, all unsaved data from the current session will be deleted (y/n)? ').lower() == 'y':
                print('Cancelled "session.load.<session_name>"')
                print('Reason: User requested cancellation.')
                return
            try:
                with open(f'sessions/{cmd_args[1]}.mtsession', 'r') as f:
                    TRACKERS = json.load(f)
                CURRENT_SESSION = cmd_args[1]
                print(f'Loaded session "{cmd_args[1]}"')
            except Exception as e:
                print('Failed to load session, please check you have spelled the session id correctly.')
                if DEBUGGING_ENABLED: print(e)
        elif cmd_args[0] == 'save':
            if len(cmd_args) == 1:
                if CURRENT_SESSION == None:
                    print('You are not currently in a session, please use session save <session_id> instead.')
                    return
                with open(f'sessions/{CURRENT_SESSION}.mtsession', 'w') as f:
                    json.dump(TRACKERS, f, indent=4)
                print(f'Saved current session to "{CURRENT_SESSION}"')
                return
            with open(f'sessions/{cmd_args[1]}.mtsession', 'w') as f:
                json.dump(TRACKERS, f, indent=4)
            CURRENT_SESSION = cmd_args[1]
            print(f'Saved current session to "{cmd_args[1]}"')
        elif cmd_args[0] == 'list':
            for f in os.listdir('sessions/'):
                print(f'Session "{".".join(f.split(".")[:-1])}"')
        elif cmd_args[0] == 'current':
            print(f'Your current session is "{CURRENT_SESSION}"')
    
    def debug(**kwargs):
        global DEBUGGING_ENABLED
        cmd_args = kwargs.get('cmd_args')
        if cmd_args[0] == 'on':
            DEBUGGING_ENABLED = True
            print('Debugging state changed to True.')
        elif cmd_args[0] == 'off':
            DEBUGGING_ENABLED = False
            print('Debugging state changed to False.')
        elif cmd_args[0] == 'state':
            print(DEBUGGING_ENABLED)

    
    commands = {
        'help':help,
        'track':track,
        'session':session,
        'debug':debug
    }

    if cmd == 'exit':
        quit()

    try:
        commands.get(cmd.split(' ')[0], command_not_found)(cmd_args=cmd.split(' ')[1:])
    except Exception as e:
        print('Error while parsing command, please make sure you have typed the right command and enough arguments.')
        if DEBUGGING_ENABLED: print(e)

if __name__ == '__main__':
    from waitress import serve
    threading.Thread(target=serve, kwargs={'app':app, 'host':'0.0.0.0', 'port':5000}).start()
    time.sleep(1)
    print('Server running on "0.0.0.0:5000"')
    while True:
        command = input('-> ')
        command_parser(command)